let carouselArr = [];

class Carousel {
    constructor(image, text, link){
        this.image = image;
        this.text = text;
        this.link = link;
    }
      
    static Start(arr){
        if(arr){
            if(arr.length > 0){
                Carousel._sequence = 0;
                Carousel._size = arr.length;
                Carousel.Next(); //start
                Carousel._interval = setInterval(function(){ Carousel.Next(); },5000);
            }
        } else {
            throw "Method Start need a Array Variable.";
        }
    }

    static Next(){
        let c = carouselArr[Carousel._sequence];
        document.getElementById("carousel").innerHTML = `<a href="${c.link}"><img src="img/${c.image}" width="100%" height="auto"></a>`;
        document.getElementById("carousel-title").innerHTML = `<a href="${c.link}">${c.text}</a>`;
        Carousel._sequence++;
        if(Carousel._sequence >= Carousel._size)
            Carousel._sequence = 0;
    }
};
